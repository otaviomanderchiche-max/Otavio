# CIRCUIT ZERO — ORIGIN Android Beta 0.6

**Aplicativo real desenvolvido em Flutter + Dart. Não há HTML, JavaScript, WebView nem motor web.**

Este pacote contém o código-fonte de uma **beta Android nativa**, com mecânicas de sobrevivência e engenharia industrial, um renderizador 2D em Flutter `CustomPainter`, simulação em Dart, UI Material adaptada a telas de toque, salvamento local e pipeline para gerar APK.

> **Situação de compilação:** o projeto foi produzido e revisado estaticamente, mas **não foi compilado nem executado com o SDK Flutter** neste ambiente. Portanto **não há APK pronto no ZIP**. A pasta `.github/workflows` contém a receita de compilação via GitHub Actions; também há scripts locais para Windows/Linux/macOS. Compile e execute os testes antes de considerar a versão pronta para distribuição.

## Como gerar um APK (Windows)

1. Instale **Flutter SDK**, **Android Studio/Android SDK** e **JDK 17**.
2. Abra esta pasta no VS Code com extensão Flutter ou no Android Studio.
3. Em terminal PowerShell, dentro desta pasta:

```powershell
flutter doctor
flutter create --platforms=android --project-name circuit_zero --org com.circuitzero .
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

4. O APK gerado aparecerá em `build/app/outputs/flutter-apk/app-release.apk`.
5. Copie o APK para o Android e instale; Android pode exigir permissão para instalar apps dessa origem.

Também é possível executar `BUILD_WINDOWS.ps1` ou disparar **Actions → Gerar APK CIRCUIT ZERO → Run workflow** depois de publicar os arquivos em um repositório GitHub seu. O APK ficará nos **Artifacts** da execução (não no botão Releases).

### Executar direto no Android por USB

```bash
flutter devices
flutter run
```

## Estrutura

```text
lib/main.dart                     Menu principal e navegação
lib/game/catalog.dart             Itens, edifícios e fórmulas
lib/game/engine.dart              Simulação, estado, mineração, economia, salvamento
lib/game/world_painter.dart       Gráficos 2D desenhados nativamente no Flutter
lib/ui/game_view.dart             HUD, joystick, painéis, missões, tutoriais
android/                          AndroidManifest, Kotlin, Gradle e ícones
assets/app_icon.png               Ícone original do aplicativo
.github/workflows/android-apk.yml Build automático de APK no GitHub Actions
test/game_engine_test.dart        Testes Flutter da lógica de fabricação
referencia_conceitual/            Catálogos do projeto anterior (referência, não todo implementado)
docs/                             Manuais e limites conhecidos
```

## O que já foi implementado no código

- Mundo 2D de exploração com árvores, pedras, galhos, fibras, ferro, cobre e carvão; recursos reaparecem gradualmente.
- Personagem com controle por joystick, caminho por toque, corrida, câmera suave e HUD adaptativa.
- Machado, picareta e progressão por ferramentas; bancadas, serraria, carvoaria e fornalha.
- Reservatórios por máquina, combustível separado, termodinâmica simplificada, seleção de receitas, velocidade, partida/parada e operação por lote ou contínua.
- Geração elétrica local simplificada, desgaste/reparação e perfuradora.
- Esteiras com transferência de itens em células adjacentes e armazém com capacidade limitada.
- Oficina eletrônica, fios, circuitos, motor e kit robótico (robôs autônomos ainda não estão ativos).
- Mercado por créditos, missões, laboratório criativo, tutoriais de descoberta e salvamento local com cópia de segurança.

## Escopo e limites

Esta **não é a implementação integral** dos catálogos conceituais anteriores de mais de 100 itens. A beta mantém **18 itens, 13 receitas (2 manuais e 11 de máquinas), 10 construções e 14 objetivos**, com foco em uma experiência real de começo ao fim. A simulação 2D é estilizada, não fotorrealista. Rede elétrica, calor e robótica são abstrações de jogo.

As funcionalidades descritas representam o código entregue; **precisam ser validadas em um aparelho Android após compilação**. Vide `docs/LIMITES_E_TESTES.md`.
