import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:circuit_zero/game/catalog.dart';
import 'package:circuit_zero/game/engine.dart';
import 'package:flutter/material.dart';

void main(){
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp((){SharedPreferences.setMockInitialValues({});});
  test('materiais nunca ficam negativos nas transações',(){
    final inv=<String,int>{'pedra':3};
    expect(canPay(inv,{'pedra':4}),isFalse);
    expect(inv['pedra'],3);
    pay(inv,{'pedra':3});
    expect(quantity(inv,'pedra'),0);
  });
  test('ferramentas e coleta inicial',(){
    final g=GameController();
    g.obtain('galho',3);g.obtain('pedra',3);g.obtain('fibra',2);
    expect(g.craft(handRecipes.first),true);
    expect(quantity(g.bag,'machado'),1);
    expect(quantity(g.bag,'galho'),2); // 2 galhos são recompensa da missão do machado
    g.dispose();
  });
  test('máquina não utiliza inventário global na produção',(){
    final g=GameController(sandbox:true);
    final serraria=g.units.firstWhere((m)=>m.type=='serraria');
    g.units.firstWhere((m)=>m.type=='gerador').running=false; // sem recompensa de missões ligada ao gerador
    final oldWood=quantity(g.bag,'madeira');
    for(int i=0;i<800;i++)g.tick(0.05);
    expect(quantity(serraria.output,'tabua'),0);
    expect(quantity(g.bag,'madeira'),oldWood);
    g.dispose();
  });
  test('máquina produz depois de ser alimentada',(){
    final g=GameController(sandbox:true);
    final saw=g.units.firstWhere((m)=>m.type=='serraria');
    expect(g.transferToMachine(saw,'madeira',2),true);
    for(int i=0;i<200;i++)g.tick(0.05);
    expect(quantity(saw.output,'tabua'),3);
    expect(quantity(saw.input,'madeira'),0);
    g.dispose();
  });
  test('combustível incompatível é rejeitado sem perder item',(){
    final g=GameController(sandbox:true);
    final furnace=g.units.firstWhere((m)=>m.type=='fornalha');
    final old=quantity(g.bag,'tabua');
    expect(g.transferToMachine(furnace,'tabua',1,asFuel:true),false);
    expect(quantity(g.bag,'tabua'),old);
    g.dispose();
  });
  test('construção checa custo e célula desocupada',(){
    final g=GameController(sandbox:true);
    g.selectBuild('bancada');
    expect(g.placeBuilding(const Offset(0,1)),false); // muito perto do jogador
    expect(g.units.length,9);
    g.dispose();
  });
  test('salvamento recupera mochila e máquinas',() async {
    final g=GameController(sandbox:true);
    await g.save();
    final reopened=GameController();
    expect(await reopened.load(),true);
    expect(quantity(reopened.bag,'machado'),1);
    expect(reopened.units.length,g.units.length);
    reopened.dispose();g.dispose();
  });
  test('receitas fazem referência apenas a itens existentes',(){
    for(final f in [...formulas,...handRecipes]) {
      for(final k in [...f.ingredients.keys,...f.result.keys]){expect(goods.containsKey(k),true,reason:'${f.id} => $k');}
    }
    for(final machine in buildings){for(final k in machine.cost.keys){expect(goods.containsKey(k),true);}}
  });
  test('margem base de cada receita de máquina é positiva',(){
  for(final recipe in formulas) {
    final cost=recipe.ingredients.entries.fold<int>(0,(a,e)=>a+(prices[e.key]??0)*e.value);
    final sale=recipe.result.entries.fold<int>(0,(a,e)=>a+(prices[e.key]??0)*e.value);
    expect(sale,greaterThan(cost),reason:recipe.id);
  }
  });
}
// Economic invariants are documented separately because operational fuel costs
// depend on equipment type and temperature. This checks only base sale margins.
