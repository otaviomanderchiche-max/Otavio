import 'package:flutter/material.dart';

class Good {
  const Good(this.id, this.name, this.icon, this.color, this.description);
  final String id;
  final String name;
  final String icon;
  final Color color;
  final String description;
}

const goods = <String, Good>{
  'galho': Good('galho', 'Galho', '🪵', Color(0xFFB99874), 'Recolha galhos caídos para produzir ferramentas.'),
  'pedra': Good('pedra', 'Pedra', '🪨', Color(0xFFA4B3AE), 'Pedras servem para ferramentas e estruturas.'),
  'fibra': Good('fibra', 'Fibra vegetal', '🌾', Color(0xFFB2CE80), 'Use fibras como amarração das primeiras ferramentas.'),
  'madeira': Good('madeira', 'Madeira', '🌳', Color(0xFFDAA574), 'Derrube árvores com machado para obter madeira.'),
  'machado': Good('machado', 'Machado', '🪓', Color(0xFFF9CB78), 'Permite cortar árvores em alguns golpes.'),
  'picareta': Good('picareta', 'Picareta', '⛏️', Color(0xFF88C7DE), 'Permite minerar depósitos metálicos e carvão.'),
  'minerio_ferro': Good('minerio_ferro', 'Minério de ferro', '⛓️', Color(0xFFE3A07E), 'Funda com combustível na fornalha.'),
  'minerio_cobre': Good('minerio_cobre', 'Minério de cobre', '🟠', Color(0xFFE7AC62), 'Origem de lingotes e fios condutores.'),
  'carvao': Good('carvao', 'Carvão mineral', '⬛', Color(0xFF91A19F), 'Pode alimentar geradores e fornalhas.'),
  'carvao_vegetal': Good('carvao_vegetal', 'Carvão vegetal', '🔥', Color(0xFFD78B65), 'Combustível renovável obtido na carvoaria.'),
  'tabua': Good('tabua', 'Tábuas', '🪵', Color(0xFFE0B787), 'Material estrutural produzido na serraria.'),
  'lingote_ferro': Good('lingote_ferro', 'Lingote de ferro', '🔩', Color(0xFFC1D0D6), 'Metal refinado para engrenagens, máquinas e ferramentas.'),
  'lingote_cobre': Good('lingote_cobre', 'Lingote de cobre', '🥉', Color(0xFFF4B26E), 'Metal usado em motores, geradores e circuitos.'),
  'engrenagem': Good('engrenagem', 'Engrenagem', '⚙️', Color(0xFFBCC9D9), 'Peça mecânica fabricada na bancada.'),
  'fio_cobre': Good('fio_cobre', 'Fio de cobre', '➰', Color(0xFFF0B77A), 'Interliga circuitos, motores e geradores.'),
  'circuito': Good('circuito', 'Circuito', '🟩', Color(0xFF82D9A4), 'Base da automação eletrônica.'),
  'motor': Good('motor', 'Motor elétrico', '🔌', Color(0xFF8DCAEF), 'Motoriza máquinas e robôs.'),
  'kit_robo': Good('kit_robo', 'Kit de robô', '🤖', Color(0xFF9ED8D1), 'Conjunto mecânico e eletrônico de um robô.'),
};

class Formula {
  const Formula(this.id, this.name, this.station, this.ingredients, this.result, this.seconds, {this.temperature = 0, this.power = 0});
  final String id, name, station;
  final Map<String, int> ingredients, result;
  final double seconds;
  final double temperature, power;
}

const handRecipes = <Formula>[
  Formula('machado', 'Machado de pedra', 'mao', {'galho':3, 'pedra':3, 'fibra':2}, {'machado':1}, 0),
  Formula('picareta', 'Picareta reforçada', 'mao', {'galho':3, 'pedra':4, 'fibra':2, 'madeira':2}, {'picareta':1}, 0),
];

const formulas = <Formula>[
  Formula('tabuas', 'Corte de tábuas', 'serraria', {'madeira':2}, {'tabua':3}, 4),
  Formula('carvao_vegetal', 'Carbonização', 'carvoaria', {'madeira':3}, {'carvao_vegetal':2}, 7),
  Formula('ferro', 'Fundição de ferro', 'fornalha', {'minerio_ferro':2, 'carvao':1}, {'lingote_ferro':1}, 7, temperature:740),
  Formula('ferro_vegetal', 'Ferro com carvão vegetal', 'fornalha', {'minerio_ferro':2, 'carvao_vegetal':1}, {'lingote_ferro':1}, 8, temperature:740),
  Formula('cobre', 'Fundição de cobre', 'fornalha', {'minerio_cobre':2, 'carvao':1}, {'lingote_cobre':1}, 7, temperature:810),
  Formula('cobre_vegetal', 'Cobre com carvão vegetal', 'fornalha', {'minerio_cobre':2, 'carvao_vegetal':1}, {'lingote_cobre':1}, 8, temperature:810),
  Formula('engrenagem', 'Usinar engrenagem', 'bancada', {'lingote_ferro':2}, {'engrenagem':1}, 5),
  Formula('fio', 'Trefilar fio', 'eletronica', {'lingote_cobre':1}, {'fio_cobre':3}, 4, power:1),
  Formula('circuito', 'Montar circuito', 'eletronica', {'fio_cobre':3, 'lingote_ferro':1}, {'circuito':1}, 8, power:2),
  Formula('motor', 'Montar motor', 'montadora', {'lingote_ferro':2, 'engrenagem':1, 'fio_cobre':2}, {'motor':1}, 9, power:3),
  Formula('kit_robo', 'Montar kit robótico', 'montadora', {'motor':1, 'circuito':1, 'lingote_ferro':2}, {'kit_robo':1}, 13, power:4),
];

class BuildingSpec {
  const BuildingSpec(this.id, this.title, this.emoji, this.cost, this.description, {this.needsPower = false});
  final String id, title, emoji, description;
  final Map<String, int> cost;
  final bool needsPower;
}

const buildings = <BuildingSpec>[
  BuildingSpec('bancada', 'Bancada mecânica', '🛠️', {'madeira':5,'pedra':4}, 'Produz engrenagens e componentes básicos.'),
  BuildingSpec('serraria', 'Serraria', '🪚', {'madeira':7,'pedra':4}, 'Transforma madeira em tábuas.'),
  BuildingSpec('carvoaria', 'Carvoaria', '♨️', {'madeira':5,'pedra':8}, 'Converte madeira em carvão vegetal.'),
  BuildingSpec('fornalha', 'Fornalha industrial', '🔥', {'pedra':12,'madeira':3,'minerio_ferro':2}, 'Fundição com combustível e controle de temperatura.'),
  BuildingSpec('armazem', 'Armazém', '📦', {'madeira':8,'pedra':6}, 'Recebe e guarda os itens transportados.'),
  BuildingSpec('esteira', 'Esteira transportadora', '➡️', {'tabua':2,'lingote_ferro':1}, 'Desloca um item por vez na direção escolhida.'),
  BuildingSpec('gerador', 'Gerador térmico', '⚡', {'lingote_ferro':5,'lingote_cobre':2,'engrenagem':2}, 'Queima combustível para fornecer eletricidade.'),
  BuildingSpec('eletronica', 'Oficina eletrônica', '🖥️', {'tabua':4,'lingote_cobre':3}, 'Produz fios e circuitos.', needsPower:true),
  BuildingSpec('montadora', 'Montadora', '🏭', {'tabua':6,'lingote_ferro':5,'engrenagem':2}, 'Monta motores e robôs.', needsPower:true),
  BuildingSpec('perfuradora', 'Perfuradora', '🔧', {'lingote_ferro':7,'motor':1}, 'Extrai automaticamente minérios nas proximidades.', needsPower:true),
];

BuildingSpec specFor(String type) => buildings.firstWhere((b) => b.id == type);
List<Formula> forStation(String station) => formulas.where((f) => f.station == station).toList();
String labelOf(String item) => goods[item]?.name ?? item;
String iconOf(String item) => goods[item]?.icon ?? '📦';
