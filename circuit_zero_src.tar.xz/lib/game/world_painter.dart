import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'engine.dart';

class WorldPainter extends CustomPainter {
  WorldPainter(this.game) : super(repaint: game.frame);
  final GameController game;
  static const double scale=60;
  static const Color dirt=Color(0xFF28443A);
  @override
  void paint(Canvas canvas,Size size) {
    final bg=Paint()..shader=const LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,
      colors:[Color(0xFF203C35),Color(0xFF162B2C),Color(0xFF183330)]).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size,bg);
    canvas.save();
    canvas.translate(size.width/2-game.camera.dx*scale,size.height/2-game.camera.dy*scale);
    canvas.scale(scale);
    final sx=game.camera.dx-size.width/scale/2-2,ex=game.camera.dx+size.width/scale/2+2;
    final sy=game.camera.dy-size.height/scale/2-2,ey=game.camera.dy+size.height/scale/2+2;
    _ground(canvas,sx,ex,sy,ey);
    final objects=<({double y,ResourceNode? node,Unit? unit,bool actor})>[];
    for(final n in game.resources) {
      if(n.hp>0 && n.position.dx>=sx-1.5&&n.position.dx<=ex+1.5&&n.position.dy>=sy-2&&n.position.dy<=ey+2){objects.add((y:n.position.dy,node:n,unit:null,actor:false));}
    }
    for(final u in game.units) {
      if(u.position.dx>=sx-2 && u.position.dx<=ex+2 &&u.position.dy>=sy-2&&u.position.dy<=ey+2){objects.add((y:u.position.dy,node:null,unit:u,actor:false));}
    }
    objects.add((y:game.player.dy,node:null,unit:null,actor:true));
    objects.sort((a,b)=>a.y.compareTo(b.y));
    for(final obj in objects){
      if(obj.actor){_player(canvas,game.player);}
      else if(obj.node!=null){_node(canvas,obj.node!);}
      else if(obj.unit!=null){_unit(canvas,obj.unit!);}
    }
    if(game.selectedBuilding!=null) {
      final p=game.player;
      canvas.drawCircle(p,9,Paint()..color=const Color(0xFF9EDBCB).withValues(alpha:0.035)
        ..style=PaintingStyle.fill);
    }
    canvas.restore();
    // Subtle depth vignette, independent of the game world.
    canvas.drawRect(Offset.zero & size,Paint()..shader=RadialGradient(
      colors:[Colors.transparent,const Color(0xFF061318).withValues(alpha:0.42)],stops:const [0.50,1.0],
      radius:0.85).createShader(Rect.fromCircle(center:Offset(size.width/2,size.height/2),radius:math.max(size.width,size.height)*0.75)));
  }
  double _rnd(int x,int y,[int salt=1]) {
    final n=(x*374761393+y*668265263+salt*1442695041)&0x7fffffff;
    var k=((n^(n>>13))*1274126177)&0x7fffffff;
    k=(k^(k>>16))&0x7fffffff;
    return k/0x7fffffff;
  }
  void _ground(Canvas c,double x0,double x1,double y0,double y1) {
    final xStart=x0.floor(),xEnd=x1.ceil(),yStart=y0.floor(),yEnd=y1.ceil();
    for(int y=yStart;y<=yEnd;y++) {
      for(int x=xStart;x<=xEnd;x++) {
        final n=_rnd(x,y);
        final rect=Rect.fromLTWH(x.toDouble(),y.toDouble(),1,1);
        final col=Color.lerp(const Color(0xFF29493D),const Color(0xFF355343),n*0.85)!;
        c.drawRect(rect,Paint()..color=col);
        if(n>0.58){c.drawOval(Rect.fromLTWH(x+0.15,y+0.23,0.63,0.37),Paint()..color=const Color(0xFF597658).withValues(alpha:0.11));}
        for(int i=0;i<5;i++) {
          final px=x+_rnd(x,y,i+11)*0.9,py=y+_rnd(x,y,i+21)*0.9;
          final shade=_rnd(x,y,i+39)>0.5?const Color(0xFF5D8463):const Color(0xFF152C2D);
          c.drawLine(Offset(px,py),Offset(px+0.016,py-0.065),Paint()..color=shade.withValues(alpha:0.32)..strokeWidth=0.012);
        }
        if(game.showGrid||game.selectedBuilding!=null){c.drawRect(rect,Paint()..color=const Color(0xFFB0D5B2).withValues(alpha:0.13)..style=PaintingStyle.stroke..strokeWidth=0.018);}
      }
    }
    // Spawn clearing: an unobtrusive earthy clearing around the starting point.
    c.drawOval(const Rect.fromLTWH(-2.4,-2,4.8,4.0),Paint()..shader=RadialGradient(colors:[const Color(0xFF907953).withValues(alpha:0.16),Colors.transparent]).createShader(const Rect.fromLTWH(-2.4,-2,4.8,4.0)));
  }
  void _ellipse(Canvas c,double x,double y,double w,double h,Color color){c.drawOval(Rect.fromLTWH(x,y,w,h),Paint()..color=color);}
  void _polygon(Canvas c,List<Offset> points,Paint p){final path=Path()..moveTo(points.first.dx,points.first.dy);for(final o in points.skip(1)){path.lineTo(o.dx,o.dy);}path.close();c.drawPath(path,p);}
  void _node(Canvas c,ResourceNode n) {
    c.save();c.translate(n.position.dx,n.position.dy);
    _ellipse(c,-0.46,0.24,0.95,0.30,const Color(0xFF051C21).withValues(alpha:0.43));
    switch(n.kind) {
      case 'arvore':
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-0.115,-0.48,0.24,0.88),const Radius.circular(0.08)),Paint()..shader=const LinearGradient(colors:[Color(0xFF513D34),Color(0xFF9B7450),Color(0xFF352D2B)]).createShader(const Rect.fromLTWH(-0.115,-0.48,0.24,0.88)));
        c.drawLine(const Offset(-0.03,-0.2),const Offset(-0.03,0.22),Paint()..color=const Color(0xFFDAC399).withValues(alpha:0.24)..strokeWidth=0.02);
        final leaves=[(-0.38,-0.54,0.49),(0.02,-0.78,0.52),(0.39,-0.52,0.45),(-0.19,-1.05,0.41),(0.22,-1.08,0.42),(0.01,-0.49,0.53)];
        for(int i=0;i<leaves.length;i++) {
          final v=leaves[i];final rect=Rect.fromCircle(center:Offset(v.$1,v.$2),radius:v.$3);
          c.drawCircle(rect.center,v.$3,Paint()..shader=RadialGradient(center:const Alignment(-0.4,-0.55),radius:1.25,
            colors:i.isEven?[const Color(0xFF6C9769),const Color(0xFF244F42),const Color(0xFF123A38)]:
              [const Color(0xFF88AC72),const Color(0xFF356B52),const Color(0xFF164038)]).createShader(rect));
          c.drawArc(rect,3.75,1.6,false,Paint()..color=const Color(0xFFA8C889).withValues(alpha:0.17)..strokeWidth=0.045..style=PaintingStyle.stroke);
        }
        for(int i=0;i<10;i++){final a=i*math.pi*2/10;_ellipse(c,math.cos(a)*0.54,math.sin(a)*0.39-0.77,0.055,0.025,const Color(0xFFC5D4A3).withValues(alpha:0.25));}
      case 'galho':
        for(int j=0;j<3;j++){
          final yy=0.04+j*0.09;
          c.drawLine(Offset(-0.26,yy),Offset(0.23,yy-0.16),Paint()..color=const Color(0xFF593F34)..strokeWidth=0.083..strokeCap=StrokeCap.round);
          c.drawLine(Offset(-0.26,yy-0.015),Offset(0.23,yy-0.175),Paint()..color=const Color(0xFFE4B98D)..strokeWidth=0.026);
        }
      case 'fibra':
        for(int i=0;i<10;i++) {
          final a=i*0.59;
          final from=Offset(math.sin(a)*0.12,0.28);
          final to=Offset(math.sin(a)*0.37,-0.27-_rnd(i,3)*0.32);
          c.drawLine(from,to,Paint()..color=(i.isEven?const Color(0xFF9FBD6D):const Color(0xFF4F865B))..strokeWidth=0.045..strokeCap=StrokeCap.round);
        }
      default:
        final metal=n.kind=='ferro'?const Color(0xFFC88B6B):n.kind=='cobre'?const Color(0xFFE5AD5B):n.kind=='carvao'?const Color(0xFF434D54):const Color(0xFFA6ADA0);
        _polygon(c,[const Offset(-0.43,0.17),const Offset(-0.37,-0.15),const Offset(-0.18,-0.34),const Offset(0.22,-0.35),const Offset(0.43,-0.08),const Offset(0.33,0.23),const Offset(-0.13,0.30)],Paint()..color=const Color(0xFF2C4140));
        _polygon(c,[const Offset(-0.40,0.05),const Offset(-0.18,-0.30),const Offset(0.17,-0.34),const Offset(0.41,-0.08),const Offset(0.18,0.12)],Paint()..color=metal);
        _polygon(c,[const Offset(-0.40,0.05),const Offset(0.18,0.12),const Offset(0.30,0.25),const Offset(-0.15,0.27)],Paint()..color=Color.lerp(metal,Colors.black,0.38)!);
        _polygon(c,[const Offset(-0.18,-0.30),const Offset(0.17,-0.34),const Offset(0.08,-0.03)],Paint()..color=Color.lerp(metal,Colors.white,0.32)!);
        if(n.kind!='pedra') {
          for(int i=0;i<4;i++){
            final x=-0.15+i*0.13;
            c.drawCircle(Offset(x,-0.11+(i.isOdd?0.13:0)),0.045,Paint()..color=Color.lerp(metal,Colors.white,0.65)!);
          }
        }
    }
    c.restore();
  }
  void _unit(Canvas c,Unit u) {
    c.save();c.translate(u.position.dx,u.position.dy);
    _ellipse(c,-0.49,0.27,1.06,0.34,const Color(0xFF091C23).withValues(alpha:0.65));
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-0.45,-0.39,0.9,0.8),const Radius.circular(0.115)),Paint()..color=const Color(0xFF121E29));
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-0.42,-0.44,0.84,0.72),const Radius.circular(0.095)),
      Paint()..shader=const LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:[Color(0xFF8D9F9F),Color(0xFF536979),Color(0xFF243844)]).createShader(const Rect.fromLTWH(-0.42,-0.44,0.84,0.72)));
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-0.34,-0.34,0.68,0.48),const Radius.circular(0.055)),Paint()..color=const Color(0xFF22333B));
    for(final p in [const Offset(-0.35,-0.36),const Offset(0.35,-0.36),const Offset(-0.35,0.20),const Offset(0.35,0.20)]){
      c.drawCircle(p,0.03,Paint()..color=const Color(0xFFC2D2D1));
      c.drawCircle(p,0.013,Paint()..color=const Color(0xFF273940));
    }
    final online=u.running&&u.health>0;
    final light=online?const Color(0xFF69E3B0):const Color(0xFFE28B74);
    c.drawCircle(const Offset(0.30,-0.30),0.057,Paint()..color=light.withValues(alpha:0.3)..maskFilter=const MaskFilter.blur(BlurStyle.normal,0.12));
    c.drawCircle(const Offset(0.30,-0.30),0.038,Paint()..color=light);
    switch(u.type){
      case 'fornalha':case 'carvoaria':
        final glow=(u.temperature/1000).clamp(0.0,1.0).toDouble();
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-0.25,-0.23,0.50,0.32),const Radius.circular(0.035)),Paint()..color=Color.lerp(const Color(0xFF18252C),const Color(0xFFFFA94A),glow)!);
        for(int i=0;i<4;i++){c.drawLine(Offset(-0.2+i*0.13,-0.2),Offset(-0.2+i*0.13,0.08),Paint()..color=const Color(0xFF12232D)..strokeWidth=0.025);}
        c.drawRect(const Rect.fromLTWH(-0.29,-0.34,0.58,0.06),Paint()..color=const Color(0xFFBCC0B1));
      case 'gerador':
        c.drawCircle(const Offset(0,-0.1),0.18,Paint()..color=const Color(0xFF1E3040));
        c.drawCircle(const Offset(0,-0.1),0.13,Paint()..color=(u.burnSeconds>0?const Color(0xFF4DCCE4):const Color(0xFF7C8793)));
        c.drawCircle(const Offset(0,-0.1),0.064,Paint()..color=const Color(0xFF13242A));
        for(int j=0;j<3;j++){
          final a=game.elapsed*2+j*math.pi*2/3;
          c.drawLine(const Offset(0,-0.1),Offset(math.cos(a)*0.12,math.sin(a)*0.12-0.1),Paint()..color=const Color(0xFFC9EEE7)..strokeWidth=0.034);
        }
      case 'esteira':
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-0.34,-0.29,0.68,0.46),const Radius.circular(0.045)),Paint()..color=const Color(0xFF17272D));
        c.save();c.rotate(u.orientation*math.pi/2);
        for(int i=-2;i<=2;i++){
          final dx=i*0.14+(game.elapsed*0.11%0.14);
          c.drawLine(Offset(dx,-0.2),Offset(dx,0.12),Paint()..color=const Color(0xFF718990)..strokeWidth=0.028);
        }
        _polygon(c,[const Offset(0.16,-0.08),const Offset(0.27,-0.04),const Offset(0.16,0.00)],Paint()..color=const Color(0xFFE0BB70));
        c.restore();
        if(u.output.isNotEmpty) c.drawCircle(const Offset(0,-0.08),0.10,Paint()..color=const Color(0xFFD9B878));
      case 'serraria':
        for(int j=0;j<4;j++){
          c.drawLine(Offset(-0.24,-0.2+j*0.08),Offset(0.18,-0.2+j*0.08),Paint()..color=const Color(0xFFB7804C)..strokeWidth=0.045);
        }
        c.drawCircle(const Offset(0.17,-0.11),0.12,Paint()..color=const Color(0xFFBACFD2));
        for(int i=0;i<10;i++){final a=i*math.pi*2/10;c.drawLine(Offset(0.17+math.cos(a)*0.09,-0.11+math.sin(a)*0.09),Offset(0.17+math.cos(a)*0.15,-0.11+math.sin(a)*0.15),Paint()..color=const Color(0xFFD3DADD)..strokeWidth=0.022);}
      case 'armazem':
        for(int i=0;i<3;i++){
          c.drawRect(Rect.fromLTWH(-0.27+i*0.16,-0.22,0.14,0.26),Paint()..color=const Color(0xFF9C7855));
          c.drawLine(Offset(-0.27+i*0.16,-0.12),Offset(-0.13+i*0.16,-0.12),Paint()..color=const Color(0xFFE4C08E)..strokeWidth=0.02);
        }
      case 'perfuradora':
        c.drawCircle(const Offset(0,-0.13),0.22,Paint()..color=const Color(0xFFB5CCCD));
        c.drawCircle(const Offset(0,-0.13),0.13,Paint()..color=const Color(0xFF35454F));
        c.drawLine(const Offset(0,-0.16),const Offset(0,0.2),Paint()..color=const Color(0xFFE2BB73)..strokeWidth=0.09);
      default:
        c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-0.24,-0.21,0.47,0.28),const Radius.circular(0.025)),Paint()..color=const Color(0xFF14242D));
        c.drawRect(const Rect.fromLTWH(-0.18,-0.16,0.27,0.08),Paint()..color=const Color(0xFF4BA1A1));
        for(int i=0;i<3;i++){c.drawCircle(Offset(-0.16+i*0.12,0.0),0.025,Paint()..color=const Color(0xFFC1DFBA));}
    }
    if(u.progress>0){
      c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-0.37,0.37,0.74,0.075),const Radius.circular(0.03)),Paint()..color=const Color(0xFF112025));
      final f=u.currentRecipe;final ratio=f==null?0.0:(u.progress/(f.seconds/u.speed)).clamp(0.0,1.0).toDouble();
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-0.37,0.37,0.74*ratio,0.075),const Radius.circular(0.03)),Paint()..color=const Color(0xFF7EE3BE));
    }
    c.restore();
  }
  void _player(Canvas c,Offset p) {
    c.save();c.translate(p.dx,p.dy);
    final bob=math.sin(game.elapsed*15)*(game.input.distance>0.1?0.045:0.01);
    _ellipse(c,-0.32,0.28,0.65,0.20,const Color(0xFF092020).withValues(alpha:0.58));
    for(final x in [-0.13,0.13]){
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x-0.06,0.1+bob,0.12,0.33),const Radius.circular(0.035)),Paint()..color=const Color(0xFF182B35));
    }
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-0.27,-0.21+bob,0.54,0.49),const Radius.circular(0.15)),Paint()..shader=const LinearGradient(colors:[Color(0xFFCF8657),Color(0xFF5D6D73),Color(0xFF293D4E)]).createShader(Rect.fromLTWH(-0.27,-0.2,0.54,0.49)));
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-0.19,-0.16+bob,0.38,0.31),const Radius.circular(0.085)),Paint()..color=const Color(0xFF324955));
    c.drawRect(Rect.fromLTWH(-0.11,-0.04+bob,0.22,0.10),Paint()..color=const Color(0xFF7CCBB4));
    c.drawCircle(Offset(0,-0.31+bob),0.21,Paint()..color=const Color(0xFFE5B58C));
    c.drawArc(Rect.fromCircle(center:Offset(0,-0.37+bob),radius:0.2),math.pi,math.pi,false,Paint()..color=const Color(0xFF29343B)..strokeWidth=0.12);
    c.drawCircle(Offset(-0.07,-0.30+bob),0.017,Paint()..color=const Color(0xFF20252A));
    c.drawCircle(Offset(0.07,-0.30+bob),0.017,Paint()..color=const Color(0xFF20252A));
    c.restore();
  }
  @override bool shouldRepaint(covariant WorldPainter oldDelegate)=>oldDelegate.game!=game;
}
