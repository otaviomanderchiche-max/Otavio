import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'catalog.dart';

int quantity(Map<String, int> m, String id) => m[id] ?? 0;
int sumItems(Map<String, int> m) => m.values.fold(0, (a, b) => a + b);
void addItem(Map<String, int> m, String id, int amount) {
  if (amount == 0) return;
  final next = (m[id] ?? 0) + amount;
  if (next <= 0) { m.remove(id); } else { m[id] = next; }
}
bool canPay(Map<String, int> bag, Map<String, int> cost) => cost.entries.every((e) => quantity(bag, e.key) >= e.value);
void pay(Map<String, int> bag, Map<String, int> cost) { for (final e in cost.entries) { addItem(bag, e.key, -e.value); } }
Map<String, int> parseStock(Object? raw) {
  if (raw is! Map) return {};
  final result = <String, int>{};
  for (final e in raw.entries) {
    if (e.key is String && e.value is num && e.value >= 0) result[e.key as String] = (e.value as num).toInt();
  }
  return result;
}

const prices=<String,int>{
  'galho':1,'pedra':2,'fibra':2,'madeira':5,
  'minerio_ferro':8,'minerio_cobre':9,'carvao':8,'carvao_vegetal':12,'tabua':13,
  'lingote_ferro':38,'lingote_cobre':40,'engrenagem':95,'fio_cobre':19,
  'circuito':190,'motor':390,'kit_robo':1000,
};

class ResourceNode {
  ResourceNode(this.id, this.kind, this.position, {this.hp = 1, this.recharge = 0});
  final int id;
  final String kind;
  final Offset position;
  int hp;
  double recharge;
  int get maxHp => switch (kind) { 'arvore' => 3, 'ferro' || 'cobre' || 'carvao' => 4, _ => 1 };
  Map<String, dynamic> toJson() => {'id':id,'hp':hp,'recharge':recharge};
}

class Unit {
  Unit(this.id, this.type, this.position, {this.orientation = 1});
  final int id;
  final String type;
  final Offset position;
  int orientation;
  Map<String,int> input = {}, output = {}, fuel = {};
  String? recipeId;
  bool running = true, continuous = true, batchRequested = false;
  double speed = 1, progress = 0, health = 100, temperature = 22, burnSeconds = 0;
  double get powerRequirement => switch (type) { 'montadora'=>3, 'eletronica'=>1, 'perfuradora'=>4, _ => 0 };
  Formula? get currentRecipe {
    final matches = forStation(type);
    if (matches.isEmpty) return null;
    for (final f in matches) { if (f.id == recipeId) return f; }
    return matches.first;
  }
  bool get acceptsFuel => type == 'fornalha' || type == 'gerador';
  bool get hasWork => type != 'esteira' && type != 'armazem' && type != 'gerador';
  int? get beltItem => output.isEmpty ? null : output.values.first;
  Map<String, dynamic> toJson() => {
    'id':id,'type':type,'x':position.dx,'y':position.dy,'orientation':orientation,
    'input':input,'output':output,'fuel':fuel,'recipeId':recipeId,'running':running,
    'continuous':continuous,'batchRequested':batchRequested,'speed':speed,
    'progress':progress,'health':health,'temperature':temperature,'burnSeconds':burnSeconds
  };
  static Unit fromJson(Map<String,dynamic> m) {
    final u=Unit((m['id'] as num).toInt(),m['type'] as String,
      Offset((m['x'] as num).toDouble(),(m['y'] as num).toDouble()), orientation:(m['orientation'] as num?)?.toInt() ?? 1);
    u.input=parseStock(m['input']);u.output=parseStock(m['output']);u.fuel=parseStock(m['fuel']);
    u.recipeId=m['recipeId'] as String?; u.running=m['running'] != false;
    u.continuous=m['continuous'] != false; u.batchRequested=m['batchRequested']==true;
    u.speed=(m['speed'] as num?)?.toDouble() ?? 1;u.progress=(m['progress'] as num?)?.toDouble() ?? 0;
    u.health=(m['health'] as num?)?.toDouble() ?? 100;u.temperature=(m['temperature'] as num?)?.toDouble() ?? 22;
    u.burnSeconds=(m['burnSeconds'] as num?)?.toDouble() ?? 0;return u;
  }
}

class Lesson {
  const Lesson(this.id, this.title, this.text);
  final String id,title,text;
}
const lessons = <String, Lesson>{
  'inicio':Lesson('inicio','Sua primeira jornada','Ande com o joystick à esquerda. Toque em galhos, pedras e fibras para se aproximar e pressione AGIR. Abra CRIAR para fabricar o machado.'),
  'galho':Lesson('galho','Encontrou um galho','Galhos são cabos para ferramentas. Junte 3 galhos, 3 pedras e 2 fibras para fazer seu primeiro machado.'),
  'pedra':Lesson('pedra','Pedras e ferramentas','Pedras soltas podem ser coletadas sem picareta. As jazidas minerais exigem uma picareta.'),
  'fibra':Lesson('fibra','Fibra vegetal','A fibra permite amarrar materiais e criar ferramentas. Colete plantas mais claras próximas às árvores.'),
  'machado':Lesson('machado','Primeiro machado!','Agora é possível cortar árvores. Aproxime-se de uma árvore e pressione AGIR algumas vezes. A madeira abre novas construções.'),
  'madeira':Lesson('madeira','Obtendo madeira','A madeira serve para fabricar a picareta, construir a bancada e dar início à indústria. O primeiro passo é criar a picareta.'),
  'picareta':Lesson('picareta','Mineração liberada','Minere as rochas de ferro (avermelhadas), cobre (alaranjadas) e carvão (escuras). Depois construa uma fornalha.'),
  'minerio_ferro':Lesson('minerio_ferro','Ferro bruto','Para fundir, construa uma fornalha, abasteça o reservatório com 2 minérios + 1 carvão, carregue combustível, ligue e aguarde aquecer.'),
  'carvao':Lesson('carvao','Carvão: dois papéis','A fornalha possui ENTRADAS da receita e COMBUSTÍVEL separado. Se a receita precisa de carvão, coloque carvão nos dois locais.'),
  'fornalha':Lesson('fornalha','Painel de fornalha','Toque na fornalha para abrir os controles. Abasteça minério e combustível, selecione receita, ligue a máquina e observe temperatura e progresso.'),
  'serraria':Lesson('serraria','Serraria e tábuas','Carregue madeira diretamente na serraria. O produto ficará no compartimento de SAÍDA até ser recolhido ou transportado.'),
  'gerador':Lesson('gerador','Rede elétrica','O gerador usa carvão ou madeira no reservatório de combustível. Quando ligado e abastecido, energiza máquinas próximas.'),
  'esteira':Lesson('esteira','Logística por esteiras','Coloque esteiras nas células adjacentes às saídas. Gire a direção antes de construir. Itens são transferidos sem passar pelo seu inventário.'),
  'eletronica':Lesson('eletronica','Circuitos e energia','A oficina eletrônica exige energia de um gerador ativo. Produza fios de cobre e monte circuitos para as tecnologias seguintes.'),
  'montadora':Lesson('montadora','Montagem avançada','Motores combinam metais, engrenagens e fios. Kits robóticos juntam motor e circuito em uma linha mais complexa.'),
  'perfuradora':Lesson('perfuradora','Mineração automática','A perfuradora exige energia e encontra depósitos minerais próximos. Verifique a saída para coletar minério.'),
};

class Objective {
  const Objective(this.title, this.requirement, this.reward);
  final String title, requirement;
  final Map<String,int> reward;
}
const objectives = <Objective>[
  Objective('Reúna galhos, pedras e fibras','collect_starter',{'pedra':2}),
  Objective('Fabrique um machado','machado',{'galho':2}),
  Objective('Corte sua primeira árvore','madeira',{'pedra':3}),
  Objective('Fabrique uma picareta','picareta',{'fibra':3}),
  Objective('Extraia minério de ferro','minerio_ferro',{'madeira':3}),
  Objective('Construa uma bancada','built:bancada',{'minerio_ferro':2}),
  Objective('Construa uma serraria','built:serraria',{'madeira':4}),
  Objective('Produza tábuas','tabua',{'pedra':3}),
  Objective('Construa uma fornalha','built:fornalha',{'carvao':3}),
  Objective('Produza um lingote de ferro','lingote_ferro',{'minerio_cobre':3}),
  Objective('Instale uma esteira','built:esteira',{'tabua':3}),
  Objective('Ative um gerador','powered',{'lingote_ferro':2}),
  Objective('Produza um circuito','circuito',{'fio_cobre':3}),
  Objective('Monte um kit robótico','kit_robo',{'circuito':1}),
];

class GameController extends ChangeNotifier {
  GameController({this.sandbox = false}) {
    _newWorld();
    if (sandbox) _setupSandbox();
    learn('inicio');
  }
  final bool sandbox;
  final ValueNotifier<int> frame = ValueNotifier<int>(0);
  final math.Random _random = math.Random(8492);
  final List<ResourceNode> resources = [];
  final List<Unit> units = [];
  final Map<String,int> bag = {};
  final Set<String> seen = {}, built = {}, shownLessons = {};
  final List<Lesson> lessonQueue = [];
  Offset player = const Offset(0, 0), camera = const Offset(0, 0);
  Offset input = Offset.zero;
  Offset? walkTo;
  int? queuedResource, queuedMachine;
  double elapsed = 0, _simulationStep = 0, _uiStep = 0, _saveStep = 0, _swingCooldown = 0;
  bool sprint = false;
  int credits = 30, missionIndex = 0, nextUnitId = 1;
  String toast = 'Comece coletando galhos, pedras e fibras.';
  String? selectedBuilding;
  int rotation = 1;
  bool showGrid = false;

  void _newWorld() {
    resources.clear();
    final placements = <String>[...List.filled(45,'arvore'),...List.filled(34,'galho'),...List.filled(30,'pedra'),
      ...List.filled(30,'fibra'),...List.filled(20,'ferro'),...List.filled(18,'cobre'),...List.filled(16,'carvao')];
    for (int i=0;i<placements.length;i++) {
      double x,y;int attempts=0;
      do {
        final radius=3.4+_random.nextDouble()*28;
        final angle=_random.nextDouble()*math.pi*2;
        x=math.cos(angle)*radius;y=math.sin(angle)*radius;
        attempts++;
      } while (attempts<100 && (resources.any((r)=>(r.position-Offset(x,y)).distance<1.1) || (x.abs()<2.3&&y.abs()<2.3)));
      final type=placements[i];
      resources.add(ResourceNode(i,type,Offset(x,y),hp:(type=='arvore'?3:((type=='ferro'||type=='cobre'||type=='carvao')?4:1))));
    }
    // Accessible starter resources near the spawn without tool requirements.
    for (final entry in <(String,Offset)>[
      ('galho',const Offset(2.8,1.0)),('pedra',const Offset(-2.7,0.7)),('fibra',const Offset(0.2,-2.6)),
      ('galho',const Offset(1.4,3.4)),('pedra',const Offset(-3.4,-1.5)),('fibra',const Offset(3.1,-1.7)),
      ('arvore',const Offset(4.0,3.2)),('ferro',const Offset(-4.4,3.8)),('carvao',const Offset(-5.5,-2.2))]) {
      resources.add(ResourceNode(resources.length,entry.$1,entry.$2,
        hp:entry.$1=='arvore'?3:(['ferro','cobre','carvao'].contains(entry.$1)?4:1)));
    }
  }
  void _setupSandbox() {
    bag.addAll({'machado':1,'picareta':1,'galho':20,'pedra':70,'fibra':20,'madeira':60,
      'tabua':60,'minerio_ferro':55,'minerio_cobre':40,'carvao':50,'carvao_vegetal':25,
      'lingote_ferro':50,'lingote_cobre':40,'engrenagem':25,'fio_cobre':25,'circuito':10,'motor':8});
    seen.addAll(bag.keys);
    for (final element in <(String,Offset)>[('bancada',Offset(-2,-3)),('serraria',Offset(-1,-3)),
      ('carvoaria',Offset(0,-3)),('fornalha',Offset(1,-3)),('esteira',Offset(2,-3)),
      ('armazem',Offset(3,-3)),('gerador',Offset(-1,-5)),('eletronica',Offset(1,-5)),('montadora',Offset(2,-5))]) {
      final u=Unit(nextUnitId++,element.$1,element.$2);units.add(u);built.add(element.$1);
    }
    units.firstWhere((e)=>e.type=='gerador').fuel['carvao']=12;
    units.firstWhere((e)=>e.type=='fornalha').fuel['carvao']=10;
    credits=250;
  }
  void toggleGrid(bool enabled){showGrid=enabled;notifyListeners();}
  void setMove(Offset value) { input=value; if (value.distance>0.05) walkTo=null; }
  void setSprint(bool on) { sprint=on; }
  void tick(double dt) {
    dt=dt.clamp(0.0,0.05).toDouble();
    elapsed+=dt;
    Offset move=input;
    if (move.distance<0.05 && walkTo!=null) {
      final delta=walkTo!-player;
      if (delta.distance<0.16) {walkTo=null;} else {move=delta/delta.distance;}
    }
    if (move.distance>0.06) {
      final direction=move.distance>1?move/move.distance:move;
      final speed=sprint?6.0:4.4;
      player+=direction*speed*dt;
      player=Offset(player.dx.clamp(-34.0,34.0).toDouble(),player.dy.clamp(-34.0,34.0).toDouble());
    }
    camera=Offset(camera.dx+(player.dx-camera.dx)*math.min(1.0,dt*6),camera.dy+(player.dy-camera.dy)*math.min(1.0,dt*6));
    _swingCooldown=math.max(0.0,_swingCooldown-dt);
    if (queuedResource!=null) {
      final matches=resources.where((r)=>r.id==queuedResource).toList();
      if (matches.isEmpty) {queuedResource=null;} else if ((matches.first.position-player).distance<=1.75) {walkTo=null;harvest(matches.first);queuedResource=null;}
    }
    if (queuedMachine!=null) {
      final matches=units.where((u)=>u.id==queuedMachine).toList();
      if (matches.isEmpty) {queuedMachine=null;} else if ((matches.first.position-player).distance<=1.9) {walkTo=null;notifyListeners();}
    }
    _simulationStep+=dt;_saveStep+=dt;_uiStep+=dt;
    if (_simulationStep>=0.12) {
      final seconds=_simulationStep;_simulationStep=0;
      _simulateMachines(seconds);
    }
    for (final node in resources) {
      if (node.hp<=0) {
        node.recharge-=dt;
        if (node.recharge<=0) node.hp=node.maxHp;
      }
    }
    if (_uiStep>=0.65) {_uiStep=0;notifyListeners();}
    if (_saveStep>=28) {_saveStep=0;unawaited(save());}
    frame.value++;
  }
  void visit(Offset world) {
    final cell=Offset(world.dx.roundToDouble(),world.dy.roundToDouble());
    if (selectedBuilding!=null) { placeBuilding(cell);return; }
    final nearestUnit = units.where((u)=>(u.position-world).distance<0.8).toList();
    if (nearestUnit.isNotEmpty) {
      final u=nearestUnit.first;
      if ((u.position-player).distance<2.1) {queuedMachine=u.id;notifyListeners();}
      else {queuedMachine=u.id;walkTo=u.position;}
      return;
    }
    final nearNode=resources.where((r)=>r.hp>0&&(r.position-world).distance<0.95).toList();
    if (nearNode.isNotEmpty) {
      final n=nearNode.first;
      if ((n.position-player).distance<=1.9) {harvest(n);} else {walkTo=n.position;queuedResource=n.id;}
    } else {walkTo=world;}
  }
  Unit? get machineToOpen {
    if (queuedMachine==null) return null;
    final found=units.where((u)=>u.id==queuedMachine && (u.position-player).distance<=2.1).toList();
    if (found.isEmpty) return null;
    queuedMachine=null;
    return found.first;
  }
  void action() {
    if (_swingCooldown>0) return;
    final possible=resources.where((n)=>n.hp>0&&(n.position-player).distance<=1.95).toList()
      ..sort((a,b)=>(a.position-player).distance.compareTo((b.position-player).distance));
    if (possible.isNotEmpty) {harvest(possible.first);return;}
    final machine=units.where((u)=>(u.position-player).distance<=1.9).toList();
    if (machine.isNotEmpty) {queuedMachine=machine.first.id;notifyListeners();return;}
    say('Chegue perto de um recurso ou máquina.');
  }
  void harvest(ResourceNode n) {
    if (n.hp<=0 || _swingCooldown>0) return;
    if (n.kind=='arvore' && quantity(bag,'machado')<1) {say('Você precisa fabricar um MACHADO primeiro.');learn('galho');return;}
    if (['ferro','cobre','carvao'].contains(n.kind) && quantity(bag,'picareta')<1) {say('Você precisa de uma PICARETA.');return;}
    _swingCooldown=0.25;
    n.hp--;
    if (n.hp==0) {
      n.recharge=n.kind=='arvore'?120:75;
      final drops= switch(n.kind) {
        'galho'=>{'galho':2},'pedra'=>{'pedra':2},'fibra'=>{'fibra':2},
        'arvore'=>{'madeira':4,'galho':2},'ferro'=>{'minerio_ferro':3},
        'cobre'=>{'minerio_cobre':3},'carvao'=>{'carvao':3},_=> <String,int>{}
      };
      for (final e in drops.entries) {obtain(e.key,e.value);}
      say(drops.entries.map((e)=>'+${e.value} ${labelOf(e.key)}').join(' · '));
    } else {say('Extração ${n.maxHp-n.hp}/${n.maxHp}');}
    notifyListeners();
  }
  void obtain(String id,int count,{bool tutorial=true}) {
    addItem(bag,id,count);
    if (seen.add(id)) {if (tutorial) learn(id);_advanceMission();}
    notifyListeners();
  }
  void learn(String id) {
    final lesson=lessons[id] ?? (goods[id]==null ? null : Lesson(id,goods[id]!.name,goods[id]!.description));
    if (lesson!=null && shownLessons.add(id)) {lessonQueue.add(lesson);notifyListeners();}
  }
  Lesson? get activeLesson => lessonQueue.isEmpty?null:lessonQueue.first;
  void dismissLesson() {if (lessonQueue.isNotEmpty)lessonQueue.removeAt(0);notifyListeners();}
  void say(String message) {toast=message;notifyListeners();}
  void _advanceMission() {
    while (missionIndex<objectives.length) {
      final required=objectives[missionIndex].requirement;
      final met=required=='collect_starter'?seen.containsAll(['galho','pedra','fibra']):
        required.startsWith('built:')?built.contains(required.substring(6)):
        required=='powered'?units.any((u)=>u.type=='gerador'&&u.burnSeconds>0):seen.contains(required);
      if (!met) break;
      final reward=objectives[missionIndex].reward;
      missionIndex++;
      for (final e in reward.entries) {addItem(bag,e.key,e.value);seen.add(e.key);}
      credits+=10;
      toast='Missão concluída! +10 créditos e materiais.';
    }
  }
  bool craft(Formula f) {
    if (!canPay(bag,f.ingredients)) {say('Materiais insuficientes para ${f.name}.');return false;}
    pay(bag,f.ingredients);
    for (final e in f.result.entries) {obtain(e.key,e.value);}
    say('${f.name} fabricado!');
    unawaited(save());return true;
  }
  bool sell(String id) {
    final price=prices[id];
    if(price==null||quantity(bag,id)<1){say('Item indisponível para venda.');return false;}
    addItem(bag,id,-1);credits+=price;say('Vendeu ${labelOf(id)} por $price CR.');return true;
  }
  bool buy(String id) {
    final price=prices[id];
    if(price==null||credits<2*price){say('Créditos insuficientes.');return false;}
    credits-=2*price;obtain(id,1);say('Comprou ${labelOf(id)} por ${2*price} CR.');return true;
  }
  void selectBuild(String id) { selectedBuilding=selectedBuilding==id?null:id;notifyListeners(); }
  void rotate() {rotation=(rotation+1)%4;notifyListeners();}
  bool placeBuilding(Offset cell) {
    final type=selectedBuilding;
    if (type==null)return false;
    if ((cell-player).distance>9) {say('Construa a até 9 células de distância.');return false;}
    if ((cell-player).distance<1.2 || units.any((m)=>(m.position-cell).distance<0.8) ||
      resources.any((n)=>n.hp>0&&(n.position-cell).distance<0.8)) {say('Essa célula está ocupada.');return false;}
    final spec=specFor(type);
    if (!canPay(bag,spec.cost)) {say('Faltam materiais para ${spec.title}.');return false;}
    pay(bag,spec.cost);
    final unit=Unit(nextUnitId++,type,cell,orientation:rotation);
    if (unit.currentRecipe!=null)unit.recipeId=unit.currentRecipe!.id;
    units.add(unit);built.add(type);learn(type);_advanceMission();
    say('${spec.title} construída! Toque nela para operar.');
    notifyListeners();unawaited(save());return true;
  }
  bool validFuel(String id) => id=='madeira'||id=='carvao'||id=='carvao_vegetal';
  bool transferToMachine(Unit unit,String id,int count,{bool asFuel=false}) {
    if (count<=0 || quantity(bag,id)<count) return false;
    if (asFuel && (!unit.acceptsFuel||!validFuel(id))) {say('Combustível incompatível.');return false;}
    if (!asFuel && (unit.type=='armazem' || unit.type=='esteira')) {
      if (unit.type=='esteira' && sumItems(unit.output)+count>1) {say('A esteira transporta apenas 1 item.');return false;}
    } else if (!asFuel && !(unit.currentRecipe?.ingredients.containsKey(id)??false)) {
      say('Esse item não faz parte da receita selecionada.');return false;
    }
    final destination=asFuel?unit.fuel:(unit.type=='esteira'||unit.type=='armazem'?unit.output:unit.input);
    if (sumItems(destination)+count>(unit.type=='armazem'?120:unit.type=='esteira'?1:40)) {say('O reservatório está cheio.');return false;}
    addItem(bag,id,-count);addItem(destination,id,count);notifyListeners();return true;
  }
  bool collect(Unit unit,String id,int count,{bool fuel=false,bool input=false}) {
    final source=fuel?unit.fuel:(input?unit.input:unit.output);
    if (count<=0 || quantity(source,id)<count)return false;
    addItem(source,id,-count);obtain(id,count);return true;
  }
  void selectRecipe(Unit u,String id) {
    if (!forStation(u.type).any((f)=>f.id==id))return;
    u.recipeId=id;u.progress=0;u.batchRequested=false;notifyListeners();
  }
  void toggleMachine(Unit u) {u.running=!u.running;notifyListeners();}
  void toggleAuto(Unit u) {u.continuous=!u.continuous;notifyListeners();}
  void requestBatch(Unit u) {u.batchRequested=true;u.running=true;notifyListeners();}
  void setMachineSpeed(Unit u,double value) {u.speed=value.clamp(0.6,1.4).toDouble();notifyListeners();}
  bool repair(Unit u) {
    if (u.health>=99.9)return false;
    final cost=<String,int>{'pedra':2,'lingote_ferro':1};
    if (!canPay(bag,cost)) {say('Manutenção: 2 pedras + 1 lingote de ferro.');return false;}
    pay(bag,cost);u.health=100;say('Manutenção concluída.');return true;
  }
  bool powered(Unit machine) => units.any((g)=>g.type=='gerador'&&g.running&&g.burnSeconds>0 && (g.position-machine.position).distance<=10);
  void _simulateMachines(double dt) {
    for (final u in units) {
      if (u.type=='gerador') {
        if (u.running && u.health>0 && u.burnSeconds<=0) _burnFuel(u);
        if (u.running && u.burnSeconds>0) {u.burnSeconds=math.max(0.0,u.burnSeconds-dt);u.health=math.max(0.0,u.health-dt*0.003);_advanceMission();}
      }
    }
    for (final u in units) {
      if (!u.running||u.health<=0)continue;
      if (u.type=='fornalha') {
        if (u.burnSeconds<=0) _burnFuel(u);
        if (u.burnSeconds>0) {u.burnSeconds=math.max(0.0,u.burnSeconds-dt);u.temperature=math.min(1050.0,u.temperature+dt*120*u.speed);}
        else {u.temperature=math.max(22.0,u.temperature-dt*44);}
      }
      if (u.type=='perfuradora') {
        if (!powered(u))continue;
        final deposit=resources.where((n)=>n.hp>0&&['ferro','cobre','carvao'].contains(n.kind)&&(n.position-u.position).distance<5).toList();
        if (deposit.isNotEmpty && sumItems(u.output)<18) {
          u.progress+=dt*u.speed;
          if (u.progress>=10) {
            u.progress=0;final node=deposit.first;node.hp--;if(node.hp==0)node.recharge=90;
            addItem(u.output,{'ferro':'minerio_ferro','cobre':'minerio_cobre','carvao':'carvao'}[node.kind]!,1);
            u.health=math.max(0.0,u.health-0.07);
          }
        }
        continue;
      }
      final f=u.currentRecipe;
      if (f==null)continue;
      if (u.powerRequirement>0&&!powered(u))continue;
      if (f.temperature>0 && (u.temperature<f.temperature||u.burnSeconds<=0))continue;
      if (!(u.continuous||u.batchRequested))continue;
      if (!canPay(u.input,f.ingredients) || sumItems(u.output)+sumItems(f.result)>24) {u.progress=0;continue;}
      u.progress+=dt;
      if (u.progress>=f.seconds/u.speed) {
        u.progress=0;pay(u.input,f.ingredients);
        for (final e in f.result.entries) {addItem(u.output,e.key,e.value);}
        u.health=math.max(0.0,u.health-0.12);
        if (!u.continuous)u.batchRequested=false;
      }
    }
    _logisticStep+=dt;
    if (_logisticStep>=0.65){_logisticStep=0;_transport();}
  }
  double _logisticStep=0;
  void _burnFuel(Unit u) {
    for (final id in ['carvao','carvao_vegetal','madeira']) {
      if (quantity(u.fuel,id)>0) {
        addItem(u.fuel,id,-1);
        u.burnSeconds=switch(id){'carvao'=>19.0,'carvao_vegetal'=>14.0,_=>9.0};
        return;
      }
    }
  }
  Offset _ahead(Unit u) => u.position+switch(u.orientation%4){0=>const Offset(0,-1),1=>const Offset(1,0),2=>const Offset(0,1),_=>const Offset(-1,0)};
  Unit? _at(Offset pos) {
    for (final u in units){if ((u.position-pos).distance<0.15)return u;}
    return null;
  }
  void _transport() {
    // Stage 1: belts already holding an item move forward (snapshot prevents multi-hop teleporting).
    final belts=units.where((u)=>u.type=='esteira'&&u.output.isNotEmpty).toList();
    for (final belt in belts) {
      final next=_at(_ahead(belt));if(next==null)continue;
      final id=belt.output.keys.first;
      if (_acceptFromBelt(next,id)) addItem(belt.output,id,-1);
    }
    // Stage 2: producers feed a belt in any adjacent cell or a warehouse directly.
    for (final source in units.where((u)=>u.type!='esteira'&&u.type!='armazem'&&u.output.isNotEmpty)) {
      final targets=units.where((u)=>(u.position-source.position).distance>0.5 && (u.position-source.position).distance<=1.1 &&
        (u.type=='esteira'||u.type=='armazem')).toList();
      for (final target in targets) {
        if (source.output.isEmpty)break;
        final id=source.output.keys.first;
        if (_acceptFromBelt(target,id)){addItem(source.output,id,-1);break;}
      }
    }
  }
  bool _acceptFromBelt(Unit dest,String id) {
    if (dest.type=='esteira') {if (sumItems(dest.output)>=1)return false;addItem(dest.output,id,1);return true;}
    if (dest.type=='armazem'){if(sumItems(dest.output)>=120)return false;addItem(dest.output,id,1);return true;}
    if (dest.currentRecipe?.ingredients.containsKey(id)==true && sumItems(dest.input)<40){addItem(dest.input,id,1);return true;}
    return false;
  }
  Future<void> save() async {
    final m=<String,dynamic>{'version':6,'player':[player.dx,player.dy],'bag':bag,'credits':credits,
      'seen':seen.toList(),'built':built.toList(),'shownLessons':shownLessons.toList(),
      'missionIndex':missionIndex,'nextUnitId':nextUnitId,'elapsed':elapsed,
      'nodes':resources.map((e)=>e.toJson()).toList(),'units':units.map((e)=>e.toJson()).toList()};
    final prefs=await SharedPreferences.getInstance();
    final old=prefs.getString('cz_game_v6');
    if(old!=null)await prefs.setString('cz_game_backup_v6',old);
    await prefs.setString('cz_game_v6',jsonEncode(m));
  }
  Future<bool> load() async {
    final prefs=await SharedPreferences.getInstance();
    for (final key in ['cz_game_v6','cz_game_backup_v6']) {
      final raw=prefs.getString(key);if(raw==null)continue;
      try {
        final data=jsonDecode(raw) as Map<String,dynamic>;
        if (data['version']!=6)continue;
        final p=data['player'] as List;player=Offset((p[0] as num).toDouble(),(p[1] as num).toDouble());camera=player;
        bag..clear()..addAll(parseStock(data['bag']));credits=(data['credits'] as num).toInt();
        seen..clear()..addAll((data['seen'] as List).cast<String>());
        built..clear()..addAll((data['built'] as List).cast<String>());
        shownLessons..clear()..addAll((data['shownLessons'] as List).cast<String>());
        missionIndex=(data['missionIndex'] as num).toInt();
        nextUnitId=(data['nextUnitId'] as num).toInt();elapsed=(data['elapsed'] as num).toDouble();
        for (final v in data['nodes'] as List) {
          final n=v as Map<String,dynamic>;final id=(n['id'] as num).toInt();
          if(id>=0 && id<resources.length){resources[id].hp=(n['hp'] as num).toInt();resources[id].recharge=(n['recharge'] as num).toDouble();}
        }
        units..clear()..addAll((data['units'] as List).map((e)=>Unit.fromJson(e as Map<String,dynamic>)));
        lessonQueue.clear();notifyListeners();return true;
      } catch (_) {continue;}
    }
    return false;
  }
  static Future<bool> hasSave() async => (await SharedPreferences.getInstance()).containsKey('cz_game_v6');
  static Future<void> eraseSave() async {
    final prefs=await SharedPreferences.getInstance();await prefs.remove('cz_game_v6');await prefs.remove('cz_game_backup_v6');
  }
  @override void dispose(){frame.dispose();super.dispose();}
}
