import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import '../game/catalog.dart';
import '../game/engine.dart';
import '../game/world_painter.dart';

const kBg=Color(0xFF101B23),kPanel=Color(0xFF1C2B33),kAccent=Color(0xFF8CE2C4),kGold=Color(0xFFF2C37B);

class OriginGameView extends StatefulWidget {
  const OriginGameView({super.key,required this.game});
  final GameController game;
  @override State<OriginGameView> createState()=>_OriginGameViewState();
}

class _OriginGameViewState extends State<OriginGameView> with SingleTickerProviderStateMixin,WidgetsBindingObserver {
  late final Ticker _ticker;
  Duration _last=Duration.zero;
  final FocusNode _focus=FocusNode();
  final Set<LogicalKeyboardKey> _pressed={};
  bool _sheetOpening=false;
  Size _worldSize=Size.zero;
  Offset _joystick=Offset.zero;
  double _joystickRadius=60;
  GameController get game=>widget.game;
  @override void initState() {
    super.initState();WidgetsBinding.instance.addObserver(this);
    game.addListener(_watchGame);
    _ticker=createTicker((now){
      final dt=_last==Duration.zero?0.016:(now-_last).inMicroseconds/1000000.0;
      _last=now;game.tick(dt);
    })..start();
    WidgetsBinding.instance.addPostFrameCallback((_){if(mounted)_focus.requestFocus();});
  }
  @override void didChangeAppLifecycleState(AppLifecycleState state) {
    if(state==AppLifecycleState.paused||state==AppLifecycleState.inactive||state==AppLifecycleState.detached){unawaited(game.save());}
  }
  void _watchGame(){
    if(!mounted)return;
    setState((){});
    if(_sheetOpening)return;
    final machine=game.machineToOpen;
    if(machine==null)return;
    _sheetOpening=true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if(!mounted)return;
      await showModalBottomSheet<void>(context:context,isScrollControlled:true,backgroundColor:kBg,
        builder:(context)=>MachineSheet(game:game,unit:machine));
      _sheetOpening=false;
      if(mounted)_focus.requestFocus();
    });
  }
  @override void dispose(){WidgetsBinding.instance.removeObserver(this);game.removeListener(_watchGame);_ticker.dispose();_focus.dispose();super.dispose();}
  void _keyboard(KeyEvent event){
    final key=event.logicalKey;
    if(event is KeyDownEvent||event is KeyRepeatEvent){
      final wasDown=_pressed.contains(key);_pressed.add(key);
      if(!wasDown){
        if(key==LogicalKeyboardKey.keyE||key==LogicalKeyboardKey.space)game.action();
        if(key==LogicalKeyboardKey.keyC)_showMenu(CraftSheet(game:game));
        if(key==LogicalKeyboardKey.keyB)_showMenu(BuildSheet(game:game));
        if(key==LogicalKeyboardKey.keyI)_showMenu(InventorySheet(game:game));
        if(key==LogicalKeyboardKey.keyM)_showMenu(QuestSheet(game:game));
        if(key==LogicalKeyboardKey.keyT)_showMenu(MarketSheet(game:game));
        if(key==LogicalKeyboardKey.keyR)game.rotate();
        if(key==LogicalKeyboardKey.escape && game.selectedBuilding!=null)game.selectBuild(game.selectedBuilding!);
      }
    } else if(event is KeyUpEvent){_pressed.remove(key);}
    final x=(_pressed.contains(LogicalKeyboardKey.keyD)||_pressed.contains(LogicalKeyboardKey.arrowRight)?1:0)-
      (_pressed.contains(LogicalKeyboardKey.keyA)||_pressed.contains(LogicalKeyboardKey.arrowLeft)?1:0);
    final y=(_pressed.contains(LogicalKeyboardKey.keyS)||_pressed.contains(LogicalKeyboardKey.arrowDown)?1:0)-
      (_pressed.contains(LogicalKeyboardKey.keyW)||_pressed.contains(LogicalKeyboardKey.arrowUp)?1:0);
    game.setMove(Offset(x.toDouble(),y.toDouble()));
    game.setSprint(_pressed.contains(LogicalKeyboardKey.shiftLeft)||_pressed.contains(LogicalKeyboardKey.shiftRight));
  }
  Future<void> _showMenu(Widget child) async {
    if(_sheetOpening)return;_sheetOpening=true;
    await showModalBottomSheet<void>(context:context,isScrollControlled:true,backgroundColor:kBg,builder:(context)=>child);
    _sheetOpening=false;if(mounted)_focus.requestFocus();
  }
  void _touch(Offset p){
    final world=Offset((p.dx-_worldSize.width/2)/WorldPainter.scale+game.camera.dx,
      (p.dy-_worldSize.height/2)/WorldPainter.scale+game.camera.dy);
    game.visit(world);
  }
  void _updateStick(Offset local){
    final d=local-Offset(_joystickRadius,_joystickRadius);
    final limited=d.distance>_joystickRadius?d/d.distance*_joystickRadius:d;
    setState(()=>_joystick=limited);
    game.setMove(limited/_joystickRadius);
  }
  void _stopStick(){setState(()=>_joystick=Offset.zero);game.setMove(Offset.zero);}
  @override Widget build(BuildContext context) {
    final short=MediaQuery.sizeOf(context).width<600;
    return KeyboardListener(
      focusNode:_focus,autofocus:true,onKeyEvent:_keyboard,
      child:Scaffold(backgroundColor:kBg,body:Stack(children:[
        LayoutBuilder(builder:(context,constraints){
          _worldSize=Size(constraints.maxWidth,constraints.maxHeight);
          return GestureDetector(behavior:HitTestBehavior.opaque,
            onTapDown:(d)=>_touch(d.localPosition),
            child:CustomPaint(size:_worldSize,painter:WorldPainter(game)));
        }),
        SafeArea(child:Align(alignment:Alignment.topCenter,child:AnimatedBuilder(animation:game,builder:(context,_){
          return _hud(short);
        }))),
        Positioned(left:16,bottom:short?108:26,child:_stick()),
        Positioned(right:18,bottom:short?112:28,child:Column(mainAxisSize:MainAxisSize.min,children:[
          _bigAction('AGIR',Icons.handyman,()=>game.action()),
          const SizedBox(height:12),
          Listener(onPointerDown:(_)=>game.setSprint(true),onPointerUp:(_)=>game.setSprint(false),
            onPointerCancel:(_)=>game.setSprint(false),child:_bigAction('CORRER',Icons.directions_run,()=>game.setSprint(!game.sprint),small:true)),
        ])),
        Positioned(left:short?8:190,right:short?8:200,bottom:short?6:18,child:_bottomBar(short)),
        if(game.selectedBuilding!=null)Positioned(left:8,right:8,top:short?126:108,child:AnimatedBuilder(animation:game,builder:(context,_){
          final spec=specFor(game.selectedBuilding!);
          return Row(mainAxisAlignment:MainAxisAlignment.center,children:[
            Flexible(child:DecoratedBox(decoration:BoxDecoration(color:const Color(0xF01A3038),borderRadius:BorderRadius.circular(18),border:Border.all(color:kAccent.withValues(alpha:0.4))),
              child:Padding(padding:const EdgeInsets.symmetric(horizontal:12,vertical:9),child:Row(mainAxisSize:MainAxisSize.min,children:[
                Expanded(child:Text('Posicione: ${spec.title}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white,fontSize:12,fontWeight:FontWeight.w600))),
                IconButton(onPressed:game.rotate,tooltip:'Girar',icon:const Icon(Icons.rotate_right,color:kAccent,size:21)),
                IconButton(onPressed:()=>game.selectBuild(game.selectedBuilding!),tooltip:'Cancelar',icon:const Icon(Icons.close,color:Colors.white70,size:21))
              ]))))
          ]);
        })),
        Positioned(top:short?175:100,left:12,right:12,child:AnimatedBuilder(animation:game,builder:(context,_){
          final lesson=game.activeLesson;if(lesson==null)return const SizedBox.shrink();
          return Align(alignment:Alignment.topCenter,child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:
            Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:const Color(0xF0203440),borderRadius:BorderRadius.circular(16),
                border:Border.all(color:kGold.withValues(alpha:0.55)),boxShadow:const [BoxShadow(color:Color(0x66000000),blurRadius:20)]),
              child:Row(children:[const Icon(Icons.menu_book_rounded,color:kGold,size:27),const SizedBox(width:10),
                Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisSize:MainAxisSize.min,children:[
                  Text(lesson.title,style:const TextStyle(color:kGold,fontWeight:FontWeight.bold,fontSize:14)),
                  Text(lesson.text,style:const TextStyle(color:Color(0xFFD7E6E3),fontSize:11,height:1.3))
                ])),IconButton(onPressed:game.dismissLesson,icon:const Icon(Icons.check_circle_outline,color:kAccent))]))));
        })),
      ])));
  }
  Widget _hud(bool short){
    final mission=game.missionIndex<objectives.length?objectives[game.missionIndex].title:'Indústria autônoma: concluída!';
    return Padding(padding:const EdgeInsets.fromLTRB(10,6,10,0),child:Column(mainAxisSize:MainAxisSize.min,children:[
      DecoratedBox(decoration:BoxDecoration(color:const Color(0xE813222C),borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white12)),
        child:Padding(padding:const EdgeInsets.symmetric(horizontal:11,vertical:8),child:Row(children:[
          Container(width:32,height:32,decoration:BoxDecoration(color:kAccent.withValues(alpha:0.15),borderRadius:BorderRadius.circular(9)),child:const Icon(Icons.bolt,color:kAccent,size:24)),
          const SizedBox(width:8),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Text('CIRCUIT ZERO',style:TextStyle(fontWeight:FontWeight.w900,color:Colors.white,letterSpacing:1.2,fontSize:13)),
            Text(short?'ORIGIN • ANDROID':'ORIGIN • ENGINEERING BETA 0.6',style:const TextStyle(fontSize:9,color:kAccent,letterSpacing:1.2))])),
          Text('◈ ${game.credits}',style:const TextStyle(color:kGold,fontWeight:FontWeight.bold)),
          IconButton(onPressed:()=>_showMenu(SettingsSheet(game:game)),icon:const Icon(Icons.settings_outlined,color:Colors.white70,size:22),tooltip:'Configurações'),
        ]))),
      const SizedBox(height:7),
      Container(padding:const EdgeInsets.symmetric(vertical:9,horizontal:13),decoration:BoxDecoration(
          color:const Color(0xE0152830),borderRadius:BorderRadius.circular(13)),child:
        Row(children:[const Icon(Icons.flag_outlined,color:kGold,size:16),const SizedBox(width:8),
          Expanded(child:Text('MISSÃO ${math.min(game.missionIndex+1,objectives.length)}/${objectives.length} • $mission',style:const TextStyle(color:Colors.white70,fontSize:11),overflow:TextOverflow.ellipsis)),
          Text('📦 ${game.bag.values.fold<int>(0,(a,b)=>a+b)}',style:const TextStyle(color:kAccent,fontSize:11,fontWeight:FontWeight.bold))])),
      Padding(padding:const EdgeInsets.only(top:4),child:Text(game.toast,maxLines:1,overflow:TextOverflow.ellipsis,
        style:const TextStyle(fontSize:11,color:Color(0xFFDBE5CD))))
    ]));
  }
  Widget _stick(){
    final d=_joystickRadius;
    return SizedBox(width:d*2,height:d*2,child:GestureDetector(behavior:HitTestBehavior.opaque,
      onPanStart:(v)=>_updateStick(v.localPosition),onPanUpdate:(v)=>_updateStick(v.localPosition),onPanEnd:(_)=>_stopStick(),onPanCancel:_stopStick,
      child:CustomPaint(painter:_JoystickPainter(_joystick))));
  }
  Widget _bigAction(String text,IconData icon,VoidCallback action,{bool small=false}){
    return GestureDetector(onTap:action,child:Container(width:small?66:83,height:small?66:83,
      decoration:BoxDecoration(shape:BoxShape.circle,color:small?const Color(0xE927434B):const Color(0xF04F927D),
        border:Border.all(color:Colors.white.withValues(alpha:0.25),width:2),
        boxShadow:const [BoxShadow(color:Color(0x55000000),blurRadius:18,offset:Offset(0,6))]),
      child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,color:Colors.white,size:small?24:29),
        Text(text,style:const TextStyle(fontSize:9,color:Colors.white,fontWeight:FontWeight.bold,letterSpacing:0.7))])));
  }
  Widget _bottomBar(bool short){
    return DecoratedBox(decoration:BoxDecoration(color:const Color(0xF0182932),borderRadius:BorderRadius.circular(17),border:Border.all(color:Colors.white10)),
      child:Padding(padding:const EdgeInsets.symmetric(vertical:4,horizontal:2),child:Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[
        _nav('CRIAR',Icons.handyman,()=>_showMenu(CraftSheet(game:game))),
        _nav('CONSTRUIR',Icons.grid_view_rounded,()=>_showMenu(BuildSheet(game:game))),
        _nav('MOCHILA',Icons.inventory_2_outlined,()=>_showMenu(InventorySheet(game:game))),
        _nav('MISSÕES',Icons.flag_outlined,()=>_showMenu(QuestSheet(game:game))),
        _nav('MERCADO',Icons.storefront_outlined,()=>_showMenu(MarketSheet(game:game))),
        _nav('GUIAS',Icons.menu_book,()=>_showMenu(TutorialSheet(game:game))),
      ])));
  }
  Widget _nav(String title,IconData icon,VoidCallback tap)=>InkWell(onTap:tap,borderRadius:BorderRadius.circular(12),
    child:Padding(padding:const EdgeInsets.symmetric(horizontal:6,vertical:5),child:Column(mainAxisSize:MainAxisSize.min,
      children:[Icon(icon,size:22,color:kAccent),const SizedBox(height:3),Text(title,style:const TextStyle(color:Colors.white70,fontSize:8,fontWeight:FontWeight.w700))])));
}

class _JoystickPainter extends CustomPainter {
  const _JoystickPainter(this.knob);
  final Offset knob;
  @override void paint(Canvas c,Size s){
    final center=Offset(s.width/2,s.height/2);
    c.drawCircle(center,s.width/2-2,Paint()..color=const Color(0x9920373E));
    c.drawCircle(center,s.width/2-3,Paint()..color=kAccent.withValues(alpha:0.18)..style=PaintingStyle.stroke..strokeWidth=2);
    c.drawCircle(center+knob,25,Paint()..shader=const LinearGradient(colors:[Color(0xFF8CDDC2),Color(0xFF397B75)]).createShader(Rect.fromCircle(center:center+knob,radius:25)));
    c.drawCircle(center+knob,12,Paint()..color=const Color(0x22FFFFFF));
  }
  @override bool shouldRepaint(covariant _JoystickPainter p)=>p.knob!=knob;
}

class SheetFrame extends StatelessWidget {
  const SheetFrame({super.key,required this.title,required this.child,this.subtitle});
  final String title;final Widget child;final String? subtitle;
  @override Widget build(BuildContext context)=>SafeArea(top:false,child:FractionallySizedBox(heightFactor:0.81,
    child:Padding(padding:const EdgeInsets.fromLTRB(15,10,15,8),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Center(child:Container(width:46,height:5,decoration:BoxDecoration(color:Colors.white24,borderRadius:BorderRadius.circular(9)))),
      const SizedBox(height:14),Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(title,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:19,color:Colors.white)),
        if(subtitle!=null)Text(subtitle!,style:const TextStyle(color:Colors.white54,fontSize:11))
      ])),IconButton(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.close,color:Colors.white70))]),
      const Divider(color:Colors.white12),Expanded(child:child)
    ]))));
}

class CraftSheet extends StatelessWidget {
  const CraftSheet({super.key,required this.game});
  final GameController game;
  @override Widget build(BuildContext context)=>SheetFrame(title:'FABRICAÇÃO MANUAL',
    subtitle:'Combine materiais coletados para criar ferramentas',
    child:AnimatedBuilder(animation:game,builder:(context,_){
      return ListView(children:[for(final recipe in handRecipes)_RecipeCard(recipe:recipe,game:game)]);
    }));
}

class _RecipeCard extends StatelessWidget {
  const _RecipeCard({required this.recipe,required this.game});final Formula recipe;final GameController game;
  @override Widget build(BuildContext context){
    final can=canPay(game.bag,recipe.ingredients);
    return Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(13),decoration:BoxDecoration(
      color:kPanel,borderRadius:BorderRadius.circular(13),border:Border.all(color:Colors.white10)),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(recipe.name,style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold)),const SizedBox(height:7),
        Wrap(spacing:7,runSpacing:5,children:recipe.ingredients.entries.map((e)=>_stockChip(e.key,e.value,quantity(game.bag,e.key))).toList()),
        const SizedBox(height:10),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:can?()=>game.craft(recipe):null,
          icon:const Icon(Icons.construction,size:17),label:Text('Fabricar · ${recipe.result.entries.map((e)=>'${e.value} ${labelOf(e.key)}').join(', ')}')))
      ]));
  }
}
Widget _stockChip(String id,int needed,int have)=>Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:6),decoration:
  BoxDecoration(color:have>=needed?const Color(0xFF254C46):const Color(0xFF4C3432),borderRadius:BorderRadius.circular(9)),
  child:Text('${iconOf(id)} $have/$needed',style:const TextStyle(color:Colors.white70,fontSize:12,fontWeight:FontWeight.w600)));

class BuildSheet extends StatelessWidget {
  const BuildSheet({super.key,required this.game});final GameController game;
  @override Widget build(BuildContext context) => SheetFrame(title:'CONSTRUÇÃO',subtitle:'Escolha uma máquina e toque em um terreno livre',
    child:AnimatedBuilder(animation:game,builder:(context,_){return ListView(children:[for(final b in buildings)
      Container(margin:const EdgeInsets.only(bottom:8),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:kPanel,borderRadius:BorderRadius.circular(13)),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Text(b.emoji,style:const TextStyle(fontSize:26)),const SizedBox(width:10),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(b.title,style:const TextStyle(fontWeight:FontWeight.bold,color:Colors.white)),
            Text(b.description,style:const TextStyle(fontSize:11,color:Colors.white60))])),
          FilledButton(onPressed:canPay(game.bag,b.cost)?(){game.selectBuild(b.id);Navigator.pop(context);}:null,
            child:const Text('Montar'))]),const SizedBox(height:9),Wrap(spacing:6,runSpacing:4,children:
              b.cost.entries.map((e)=>_stockChip(e.key,e.value,quantity(game.bag,e.key))).toList())]))] );}));
}

class InventorySheet extends StatelessWidget {
  const InventorySheet({super.key,required this.game});final GameController game;
  @override Widget build(BuildContext context)=>SheetFrame(title:'MOCHILA',subtitle:'Recursos, ferramentas e produtos',
    child:AnimatedBuilder(animation:game,builder:(context,_){
      final list=game.bag.entries.where((e)=>e.value>0).toList()..sort((a,b)=>labelOf(a.key).compareTo(labelOf(b.key)));
      return ListView(children:[for(final e in list)ListTile(leading:Text(iconOf(e.key),style:const TextStyle(fontSize:24)),
        title:Text(labelOf(e.key),style:const TextStyle(color:Colors.white)),subtitle:Text(goods[e.key]?.description??'',style:const TextStyle(fontSize:11,color:Colors.white54)),
        trailing:Text('×${e.value}',style:const TextStyle(color:kAccent,fontWeight:FontWeight.bold,fontSize:16))) ]);
    }));
}

class QuestSheet extends StatelessWidget {
  const QuestSheet({super.key,required this.game});final GameController game;
  @override Widget build(BuildContext context)=>SheetFrame(title:'JORNADA INDUSTRIAL',subtitle:'Evolua da sobrevivência até a robótica',
    child:AnimatedBuilder(animation:game,builder:(context,_){return ListView.builder(itemCount:objectives.length,itemBuilder:(context,i){
      final passed=i<game.missionIndex,active=i==game.missionIndex;
      return Card(color:active?const Color(0xFF26463E):kPanel,child:ListTile(
        leading:Icon(passed?Icons.check_circle:active?Icons.radio_button_checked:Icons.lock_outline,color:passed?kAccent:active?kGold:Colors.white24),
        title:Text('${i+1}. ${objectives[i].title}',style:TextStyle(color:passed?Colors.white60:Colors.white,fontWeight:active?FontWeight.bold:FontWeight.normal)),
        subtitle:Text('Recompensa: +10 CR · ${objectives[i].reward.entries.map((e)=>'${e.value} ${labelOf(e.key)}').join(', ')}',
          style:const TextStyle(fontSize:11,color:Colors.white54))));
    });}));
}

class MarketSheet extends StatelessWidget {
  const MarketSheet({super.key,required this.game});
  final GameController game;
  @override Widget build(BuildContext context)=>SheetFrame(title:'MERCADO INDUSTRIAL',
    subtitle:'Venda excedentes e compre materiais de emergência',
    child:AnimatedBuilder(animation:game,builder:(context,_){
      return ListView(children:[
        Padding(padding:const EdgeInsets.all(12),child:Text('SALDO: ◈ ${game.credits} CR',style:const TextStyle(color:kGold,fontWeight:FontWeight.bold,fontSize:18))),
        for(final entry in prices.entries)Card(color:kPanel,child:Padding(padding:const EdgeInsets.symmetric(horizontal:9,vertical:7),
          child:Row(children:[Text(iconOf(entry.key),style:const TextStyle(fontSize:21)),const SizedBox(width:7),
            Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text(labelOf(entry.key),maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white,fontSize:12)),
              Text('Você tem ${quantity(game.bag,entry.key)} • venda ${entry.value} CR',style:const TextStyle(color:Colors.white54,fontSize:10))])),
            _tradeButton('VENDER',quantity(game.bag,entry.key)>0?()=>game.sell(entry.key):null),const SizedBox(width:5),
            _tradeButton('COMPRAR',game.credits>=entry.value*2?()=>game.buy(entry.key):null),
          ]))),
      ]);
    }));
  Widget _tradeButton(String text,VoidCallback? fn)=>SizedBox(height:32,child:OutlinedButton(onPressed:fn,
    style:OutlinedButton.styleFrom(minimumSize:const Size(25,30),padding:const EdgeInsets.symmetric(horizontal:7),side:const BorderSide(color:Colors.white30)),
    child:Text(text,style:const TextStyle(fontSize:9))));
}

class TutorialSheet extends StatelessWidget {
  const TutorialSheet({super.key,required this.game});final GameController game;
  @override Widget build(BuildContext context)=>SheetFrame(title:'GUIA DE CAMPO',subtitle:'Tutoriais desbloqueados ao descobrir recursos',
    child:AnimatedBuilder(animation:game,builder:(context,_){
      final list=lessons.values.where((l)=>game.shownLessons.contains(l.id)).toList();
      return ListView(children:[for(final l in list)Card(color:kPanel,child:ExpansionTile(title:Text(l.title,style:const TextStyle(color:Colors.white)),
        leading:const Icon(Icons.school_outlined,color:kAccent),iconColor:kAccent,collapsedIconColor:Colors.white60,
        children:[Padding(padding:const EdgeInsets.fromLTRB(16,0,16,15),child:Text(l.text,style:const TextStyle(color:Colors.white70,height:1.45)))]))]);
    }));
}

class MachineSheet extends StatelessWidget {
  const MachineSheet({super.key,required this.game,required this.unit});final GameController game;final Unit unit;
  @override Widget build(BuildContext context){
    final spec=specFor(unit.type);
    return SheetFrame(title:'${spec.emoji} ${spec.title}',subtitle:'Painel técnico • ID #${unit.id} • reservatórios individuais',
      child:AnimatedBuilder(animation:game,builder:(context,_){
        final recipe=unit.currentRecipe;
        final needsPower=unit.powerRequirement>0;
        final working=unit.running&&unit.health>0&&(!needsPower||game.powered(unit));
        return ListView(children:[
          Row(children:[_status(working?'EM OPERAÇÃO':'PARADA',working?kAccent:const Color(0xFFE7A077)),
            const SizedBox(width:8),_status('Integridade ${unit.health.toStringAsFixed(0)}%',kGold),
            if(needsPower)...[const SizedBox(width:8),_status(game.powered(unit)?'ENERGIA OK':'SEM ENERGIA',game.powered(unit)?kAccent:Colors.redAccent)] ]),
          const SizedBox(height:12),
          if(unit.acceptsFuel)...[
            _infoPanel('Combustão',unit.type=='fornalha'?'Temperatura ${unit.temperature.toStringAsFixed(0)} °C • ${unit.burnSeconds.toStringAsFixed(0)} s de chama':'Carga térmica restante: ${unit.burnSeconds.toStringAsFixed(0)} s'),
            const SizedBox(height:10),
          ],
          if(recipe!=null)...[
            const Text('RECEITA DE PRODUÇÃO',style:TextStyle(color:kAccent,letterSpacing:1.1,fontWeight:FontWeight.bold,fontSize:12)),const SizedBox(height:8),
            Wrap(spacing:7,runSpacing:7,children:[for(final f in forStation(unit.type))ChoiceChip(label:Text(f.name),selected:recipe.id==f.id,
              onSelected:(_)=>game.selectRecipe(unit,f.id),selectedColor:const Color(0xFF386D63),backgroundColor:kPanel,labelStyle:const TextStyle(color:Colors.white,fontSize:11))]),
            const SizedBox(height:10),
            Text('Exige: ${recipe.ingredients.entries.map((e)=>'${e.value} ${labelOf(e.key)}').join(' + ')}',style:const TextStyle(color:Colors.white70,fontSize:12)),
            Text('Entrega: ${recipe.result.entries.map((e)=>'${e.value} ${labelOf(e.key)}').join(' + ')} • ${recipe.seconds.toStringAsFixed(0)}s',style:const TextStyle(color:Colors.white54,fontSize:11)),
            if(recipe.temperature>0)Text('Temperatura mínima: ${recipe.temperature.toStringAsFixed(0)}°C',style:const TextStyle(color:kGold,fontSize:11)),
            const SizedBox(height:10),LinearProgressIndicator(value:(unit.progress/(recipe.seconds/unit.speed)).clamp(0.0,1.0).toDouble(),backgroundColor:Colors.white12,color:kAccent,minHeight:7,borderRadius:BorderRadius.circular(7)),
            const SizedBox(height:12),
          ],
          Row(children:[Expanded(child:FilledButton.icon(onPressed:()=>game.toggleMachine(unit),icon:Icon(unit.running?Icons.pause:Icons.play_arrow),
            label:Text(unit.running?'DESLIGAR':'LIGAR'))),const SizedBox(width:8),
            Expanded(child:OutlinedButton.icon(onPressed:()=>game.toggleAuto(unit),icon:const Icon(Icons.sync,size:18),
              label:Text(unit.continuous?'CONTÍNUO':'MANUAL')))]),
          if(recipe!=null && !unit.continuous)OutlinedButton.icon(onPressed:()=>game.requestBatch(unit),icon:const Icon(Icons.precision_manufacturing),label:const Text('EXECUTAR 1 CICLO')),
          if(recipe!=null)Row(children:[const Text('Velocidade',style:TextStyle(color:Colors.white70,fontSize:12)),
            Expanded(child:Slider(value:unit.speed,min:0.6,max:1.4,divisions:8,activeColor:kAccent,onChanged:(v)=>game.setMachineSpeed(unit,v))),
            Text('${(unit.speed*100).round()}%',style:const TextStyle(color:Colors.white))]),
          if(unit.type=='armazem'||unit.type=='esteira')
            _inventorySection('ARMAZENAMENTO • entrada e retirada',unit.output,game,unit,
              (id,n)=>game.transferToMachine(unit,id,n),keys:game.bag.keys.toList()),
          if(unit.type!='armazem'&&unit.type!='esteira')...[
            _inventorySection('ENTRADAS • carregamento manual',unit.input,game,unit,
              (id,n)=>game.transferToMachine(unit,id,n),
              keys:recipe?.ingredients.keys.toList()??[],input:true),
            if(unit.acceptsFuel)_inventorySection('TANQUE DE COMBUSTÍVEL',unit.fuel,game,unit,
              (id,n)=>game.transferToMachine(unit,id,n,asFuel:true),
              keys:const ['madeira','carvao','carvao_vegetal'],fuel:true),
            _inventorySection('SAÍDAS • retirar produtos',unit.output,game,unit,
              (id,n)=>game.transferToMachine(unit,id,n),keys:const [],output:true),
          ],
          const SizedBox(height:12),OutlinedButton.icon(onPressed:unit.health<100?()=>game.repair(unit):null,
            icon:const Icon(Icons.build),label:const Text('MANUTENÇÃO (2 pedras + 1 lingote)')),
          const SizedBox(height:30)
        ]);
      }));
  }
  Widget _status(String label,Color color)=>Container(padding:const EdgeInsets.symmetric(vertical:7,horizontal:8),decoration:BoxDecoration(
    color:color.withValues(alpha:0.11),border:Border.all(color:color.withValues(alpha:0.45)),borderRadius:BorderRadius.circular(8)),
    child:Text(label,style:TextStyle(fontSize:10,fontWeight:FontWeight.bold,color:color)));
  Widget _infoPanel(String title,String body)=>Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFF26373B),borderRadius:BorderRadius.circular(9)),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(color:kGold,fontWeight:FontWeight.bold)),
      Text(body,style:const TextStyle(color:Colors.white70))]));
  Widget _inventorySection(String title,Map<String,int> stock,GameController game,Unit unit,
    bool Function(String,int) insert,{required List<String> keys,bool input=false,bool fuel=false,bool output=false}) {
    final ids=<String>{...stock.keys,...keys}.toList();
    return Container(margin:const EdgeInsets.only(top:12),padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:kPanel,borderRadius:BorderRadius.circular(12)),
      child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Text(title,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:12,color:kAccent,letterSpacing:0.7)),const SizedBox(height:6),
        if(ids.isEmpty)const Text('Vazio',style:TextStyle(color:Colors.white38)),
        for(final id in ids)Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(children:[
          Text(iconOf(id),style:const TextStyle(fontSize:18)),const SizedBox(width:6),
          Expanded(child:Text(labelOf(id),overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white,fontSize:12))),
          Text('${quantity(stock,id)}',style:const TextStyle(color:kGold,fontWeight:FontWeight.bold)),const SizedBox(width:7),
          if(!output)...[
            _micro('＋1',quantity(game.bag,id)>0?()=>insert(id,1):null),const SizedBox(width:4),
            _micro('＋5',quantity(game.bag,id)>=5?()=>insert(id,5):null),const SizedBox(width:4),
          ],
          _micro('−1',quantity(stock,id)>0?()=>game.collect(unit,id,1,fuel:fuel,input:input):null),
          const SizedBox(width:4),
          _micro('TUDO',quantity(stock,id)>0?()=>game.collect(unit,id,quantity(stock,id),fuel:fuel,input:input):null),
        ]))
      ]));
  }
  Widget _micro(String text,VoidCallback? callback)=>SizedBox(height:32,child:OutlinedButton(onPressed:callback,
    style:OutlinedButton.styleFrom(padding:const EdgeInsets.symmetric(horizontal:7),minimumSize:const Size(30,32),side:const BorderSide(color:Colors.white24)),
    child:Text(text,style:const TextStyle(fontSize:10))));
}

class SettingsSheet extends StatelessWidget {
  const SettingsSheet({super.key,required this.game});final GameController game;
  @override Widget build(BuildContext context)=>SheetFrame(title:'CONFIGURAÇÕES',subtitle:'Sua partida é salva automaticamente',
    child:AnimatedBuilder(animation:game,builder:(context,_){return ListView(children:[
      SwitchListTile(value:game.showGrid,onChanged:(v){game.toggleGrid(v);},title:const Text('Mostrar grade de construção'),activeColor:kAccent),
      ListTile(leading:const Icon(Icons.save_outlined,color:kAccent),title:const Text('Salvar agora'),onTap:(){unawaited(game.save());ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Salvamento solicitado.')));}),
      ListTile(leading:const Icon(Icons.info_outline,color:kGold),title:const Text('CIRCUIT ZERO — Flutter/Dart 0.6'),subtitle:const Text('Aplicativo nativo Android • sem HTML • progresso local')),
      const Padding(padding:EdgeInsets.all(12),child:Text('Controles: joystick/arrastar; AGIR para coletar; toque em máquinas e recursos; CONSTRUIR para posicionar equipamentos. No PC: WASD, E, C, B, I e M.',style:TextStyle(color:Colors.white60)))
    ]);}));
}
