import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'game/engine.dart';
import 'ui/game_view.dart';

void main(){
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:Colors.transparent,systemNavigationBarColor:Color(0xFF101B23),
    statusBarIconBrightness:Brightness.light,systemNavigationBarIconBrightness:Brightness.light));
  runApp(const CircuitZeroApp());
}

class CircuitZeroApp extends StatelessWidget {
  const CircuitZeroApp({super.key});
  @override Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      title:'CIRCUIT ZERO • ORIGIN',
      theme:ThemeData(useMaterial3:true,brightness:Brightness.dark,
        scaffoldBackgroundColor:kBg,
        colorScheme:ColorScheme.fromSeed(seedColor:kAccent,brightness:Brightness.dark),
        filledButtonTheme:FilledButtonThemeData(style:FilledButton.styleFrom(backgroundColor:const Color(0xFF467E72),foregroundColor:Colors.white,
          padding:const EdgeInsets.symmetric(horizontal:15,vertical:12),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(11)))),
        sliderTheme:const SliderThemeData(trackHeight:3)),
      home:const WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});
  @override State<WelcomeScreen> createState()=>_WelcomeScreenState();
}
class _WelcomeScreenState extends State<WelcomeScreen> {
  bool _busy=false;
  Future<void> _open({required bool load, bool sandbox=false}) async {
    if(_busy)return;
    setState(()=>_busy=true);
    final game=GameController(sandbox:sandbox);
    if(load) {final success=await game.load();if(!success && mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Salvamento não encontrado ou incompatível. Nova jornada iniciada.')));}}
    if(!mounted){game.dispose();return;}
    await Navigator.of(context).push(MaterialPageRoute(builder:(_)=>OriginGameView(game:game)));
    await game.save();game.dispose();
    if(mounted)setState(()=>_busy=false);
  }
  @override Widget build(BuildContext context){
    return Scaffold(body:LayoutBuilder(builder:(context,constraints){
      final width=constraints.maxWidth;
      return Stack(children:[
        Positioned.fill(child:CustomPaint(painter:_WelcomeArt())),
        Positioned.fill(child:DecoratedBox(decoration:BoxDecoration(gradient:LinearGradient(begin:Alignment.centerLeft,end:Alignment.bottomRight,
          colors:[const Color(0xFF101B23).withValues(alpha:0.96),const Color(0xFF11292C).withValues(alpha:0.72),const Color(0xFF101B23).withValues(alpha:0.3)])))),
        SafeArea(child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:780),child:Padding(
          padding:const EdgeInsets.symmetric(horizontal:29,vertical:22),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Row(children:[Container(width:40,height:40,decoration:BoxDecoration(color:kAccent.withValues(alpha:0.18),borderRadius:BorderRadius.circular(11)),
              child:const Icon(Icons.precision_manufacturing_rounded,color:kAccent,size:25)),const SizedBox(width:12),
              const Text('INDEPENDENT ENGINEERING LAB',style:TextStyle(color:Color(0xFFB0D8CF),letterSpacing:2,fontSize:10,fontWeight:FontWeight.bold))]),
            const Spacer(flex:2),
            Text('CIRCUIT',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,letterSpacing:width>650?7.0:2.0,
              height:0.95,fontSize:width>650?70.0:54.0)),
            Text('ZERO',style:TextStyle(color:kAccent,fontWeight:FontWeight.w900,letterSpacing:width>650?14.0:9.0,
              height:1.0,fontSize:width>650?88.0:65.0)),
            const SizedBox(height:15),
            const Text('ORIGIN • BETA NATIVA 0.6',style:TextStyle(fontWeight:FontWeight.w700,color:kGold,letterSpacing:2,fontSize:12)),
            const SizedBox(height:15),
            const Text('Comece com galhos e pedras. Construa ferramentas, domine o fogo, funda metais e programe o futuro da sua indústria.',
              style:TextStyle(fontSize:15,color:Color(0xFFD4E3E1),height:1.6)),
            const Spacer(flex:2),
            _button('NOVA JORNADA',Icons.forest_outlined,()=>_open(load:false),main:true),
            const SizedBox(height:9),
            FutureBuilder<bool>(future:GameController.hasSave(),builder:(context,snapshot){
              return _button('CONTINUAR',Icons.restore_outlined,snapshot.data==true?()=>_open(load:true):null);
            }),
            const SizedBox(height:9),
            _button('LABORATÓRIO — EXPERIMENTAR FÁBRICA',Icons.science_outlined,()=>_open(load:false,sandbox:true)),
            const SizedBox(height:17),
            const Text('FLUTTER + DART  •  ANDROID NATIVO  •  OFFLINE',style:TextStyle(color:Colors.white38,fontSize:9,letterSpacing:1.3)),
          ])))))
      ]);
    }));
  }
  Widget _button(String text,IconData icon,VoidCallback? cb,{bool main=false}){
    return SizedBox(width:double.infinity,height:53,child:FilledButton.icon(
      style:FilledButton.styleFrom(backgroundColor:main?kAccent:const Color(0xFF263D44),foregroundColor:main?kBg:Colors.white,
        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12))),
      onPressed:_busy?null:cb,icon:Icon(icon,size:19),label:Text(text,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:12,letterSpacing:0.5))));
  }
}

class _WelcomeArt extends CustomPainter {
  @override void paint(Canvas c,Size size){
    final rect=Offset.zero & size;
    c.drawRect(rect,Paint()..shader=const LinearGradient(colors:[Color(0xFF25483C),Color(0xFF0B1F27)],begin:Alignment.topLeft,end:Alignment.bottomRight).createShader(rect));
    for(int i=0;i<55;i++){
      final x=(i*173.0)%size.width,y=(i*127.0)%size.height;
      final r=10.0+(i%5)*13.0;
      c.drawCircle(Offset(x,y),r,Paint()..color=(i%2==0?const Color(0xFF467E61):const Color(0xFF4A6E71)).withValues(alpha:0.14));
      c.drawCircle(Offset(x,y),r*0.56,Paint()..color=const Color(0xFF82A586).withValues(alpha:0.05));
    }
    for(int j=0;j<5;j++) {
      final x=size.width*0.60+j*41.0,y=size.height*0.56+(j%3)*34.0;
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x,y,56,42),const Radius.circular(8)),Paint()..color=const Color(0xFF859B9A).withValues(alpha:0.37));
      c.drawRect(Rect.fromLTWH(x+10,y+8,32,14),Paint()..color=const Color(0xFF19323C).withValues(alpha:0.68));
      c.drawCircle(Offset(x+43,y+10),3.5,Paint()..color=kAccent.withValues(alpha:0.75));
    }
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>false;
}
